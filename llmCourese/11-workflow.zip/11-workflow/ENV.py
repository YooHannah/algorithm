import os 
deep_seek_url = os.environ["DEEPSEEK_BASE_URL"]
deep_seek_api_key = os.environ["DEEPSEEK_API_KEY"]
deep_seek_default_model = 'deepseek-chat'